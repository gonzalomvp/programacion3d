#pragma once
#include <string>

std::string readString(const std::string& filename);